function checkRelationship() {
  const name1 = document.getElementById("name1").value.trim().toLowerCase();
  const name2 = document.getElementById("name2").value.trim().toLowerCase();
  const resultBox = document.getElementById("result");

  if (!name1 || !name2) {
    resultBox.innerHTML = "Both names are required 😭";
    return;
  }

  const key = `${name1}_${name2}`;
  const saved = localStorage.getItem(key);
  if (saved) {
    resultBox.innerHTML = saved;
    return;
  }

  const percentage = Math.floor(Math.random() * 51) + 50;

  const messages = [
    `Certified situationship 💔`,
    `Y’all belong to the streets 🥀`,
    `It’s giving red light not green 💔`,
    `Too real to be fake, too fake to be real 💀`,
    `Delulu love arc incoming 😭`,
    `Enemies to lovers? Nah 💀`,
    `You sure this ain’t trauma bonding? 🤭`,
    `Toxic but trending 💅`,
    `Stay, slay, or run away? 😋`,
    `This ship leaking but still sailing 😭`,
    `Love or lore? We’ll never know 🎀`,
    `That’s not love, that’s dopamine 💀`,
    `Situationship with benefits 🤭`,
    `Lowkey obsessed, highkey unstable 💔`,
    `You get butterflies, but they got options 💀`,
    `Green flag? More like beige 🥀`,
    `Text chemistry but real life dry AF 😋`,
    `Vibes are vibing, but brain cells are dying 💀`,
    `Main character energy, side quest couple 💔`,
    `You posting them, they posting close friends 🤭`,
    `Only works on Sundays and delulu days 🎀`,
    `Toxic compatibility unlocked 💅`,
    `One of y’all lying and it ain’t me 💀`,
    `Looks good on IG, cries on call 😭`,
    `Red flags wrapped in pink bows 🎀`,
    `Rizz was immaculate, until reality hit 💔`,
    `Simp certified 🤭`,
    `Love bombed and ghosted 😭`,
    `Good morning texts but still blocked 💀`,
    `Ya'll cute but therapy cuter 😋`,
    `You dating or just trauma mirroring 🥀`,
    `Y’all a whole novella 🎀`,
    `They’re the ick, you’re the pick 🤭`,
    `Situationship status: It’s complicated af 💀`,
    `More problems than pixels 💔`
  ];

  const randomMessage = messages[Math.floor(Math.random() * messages.length)];

  const finalResult = `
    <p style="font-size: 20px; font-weight: 600;">Compatibility: ${percentage}%</p>
    <p>${randomMessage}</p>
  `;

  resultBox.innerHTML = finalResult;
  localStorage.setItem(key, finalResult);
}
