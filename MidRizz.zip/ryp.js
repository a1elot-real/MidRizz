let rated = false;

function ratePhoto() {

  const fileInput = document.getElementById("photoInput");

  const resultBox = document.getElementById("result");

  if (rated) {

    resultBox.innerHTML = "Nice try nigga you're already rated!";

    return;

  }

  if (!fileInput.files || fileInput.files.length === 0) {

    resultBox.innerHTML = "Upload a pic first 😭";

    return;

  }

  resultBox.innerHTML = "Analyzing please wait MidRizz...✨🎀<br><small></small>";

  setTimeout(() => {

    const scores = [

      "ts is so tuff please click well pic 🥀 1/10",

      "hell nawh, go lobby lilnigga😭🙏🏻 2/10",

      "Bro learn photography from Africa 😭💔 3/10",

      "Sybau bro, appreciate your confident 🙏🏻🥀 4/10",

      "The real mid 💔🥀 5/10",

      "Appreciable 😋 6/10",

      "goated pic no cap 🤩 7/10",
