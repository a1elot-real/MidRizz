function findSoulmate() {
  const name = document.getElementById("yourName").value.trim().toLowerCase();
  const resultBox = document.getElementById("result");

  if (!name) {
    resultBox.innerHTML = "Please enter your name 😭";
    return;
  }

  const key = `soulmate_${name}`;
  const stored = localStorage.getItem(key);

  if (stored) {
    resultBox.innerHTML = "NICE TRY DIDDY 😹 You already checked!";
    return;
  }

  const alphabets = "ABCDFGHJKLMNOPRSTUV";
  const chosen = alphabets[Math.floor(Math.random() * alphabets.length)];

  const accuracy = Math.floor(Math.random() * 11) + 90; // 90–100%

  const message = `
    <p>Your soulmate's name starts with: <strong>${chosen}</strong> 💖</p>
    <p>Based on astrology, this is <strong>${accuracy}% accurate</strong> 🌙</p>
  `;

  resultBox.innerHTML = message;
  localStorage.setItem(key, message);
}